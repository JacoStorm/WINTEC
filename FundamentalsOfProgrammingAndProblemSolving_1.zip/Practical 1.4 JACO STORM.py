'''
Author: Jaco Storm 15435194

Pledge of Homour: I pledge by honout that this program is solely my own work.

Program FOUR
Description: This program creates a sequence of circles on the users request
that ranch from biggest to smallist
'''

from turtle import *

# Declare variables
r = int(textinput('Radius','Enter radius(40 – 70 incl): '))  # Start size of radius
while r < 40 or r > 70: # User input check
    r = int(textinput('ERROR INVALID VALUE','Re-Enter radius(40 – 70 incl)'))
yCo = int(textinput('Y Co-ordinate','Enter Y Co-ordinate posistion(0 to -200): ')) # Start location for Y co-ordinate
while yCo < -200 or yCo > 0: # User input check
    yCo = int(textinput('ERROR INVALID VALUE','Re-Enter Y Co-ordinate posistion(0 to -200): '))
xCo = int(textinput('X Co-ordinate','Enter X Co-ordinate posistion(0 to -200): ')) # Start location for x co-ordinate
while xCo < -200 or xCo > 0: # User input check
    xCo = int(textinput('ERROR INVALID VALUE','Re-Enter X Co-ordinate posistion(0 to -200): '))
shnk = int(textinput('Shink','Enter shrink value: ')) # Value of circle shrink
while shnk > r or shnk < 0: # User input check
    shnk = int(textinput('ERROR INVALID VALUE','Re-Enter shrink value: '))
count = 0 # Counting variable for loop
stop = 5

while yCo < -200 or yCo > 0:
    yCo = int(textinput('ERROR INVALID VALUE','Enter Y Co-ordinate posistion: '))
while r >= stop:
    print('Circle',count)
    print('Goto',xCo,',',yCo)
    print('r = ',r)
    print('------------------')
    # Move pen into posistion
    penup() 
    goto(xCo,yCo)
    pendown()
    # Draw circle
    circle(r)
    # Calculate x and y for next circle
    yCo = yCo + r * 2
    r -= shnk
    count += 1
    
print('Completed')
   
