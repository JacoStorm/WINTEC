'''
Author: Jaco Storm 15435194

Pledge of Homour: I pledge by honout that this program is solely my own work.

Program TWO
Description: This program returns a month when the user enters the corrosponding
months's order number.
'''

# Get input
num = int(input('Enter your number to identify the month (1-12) :'))

# Check user input
while 1 > num or 12 < num: # Error condition statment
    num = int(input('INVALID ENTRY, your number must between 1 and 12, Try again: ')) # Correct re-entry prompt

print('--------------------------------------------------------------------') # line to help read output
# Check corrosponding month
count = 1 # Set up counter
while count <= num: # Output each month in sequence
    if count == 1:
        print('January')
    elif count == 2:
        print('February')
    elif count == 3:
        print('March')
    elif count == 4:
        print('April')
    elif count == 5:
        print('May')
    elif count == 6:
        print('June')
    elif count == 7:
        print('July')
    elif count == 8:
        print('August')
    elif count == 9:
        print('September')
    elif count == 10:
        print('October')
    elif count == 11:
        print('November')
    else:
        print('December')
    count += 1
print('--------------------------------------------------------------------') # line to help read output

print('Thanks - Hope you can remeber them next time!') # End of program note
