'''
Author: Jaco Storm 15435194

Pledge of Homour: I pledge by honout that this program is solely my own work.

Program THREE
Description: program to check whether user qualifies for a home loan
'''
# Declaring varibals
true = 'You are eligible'
false = 'Sorry, you are not eligible'


# Input family annual income
fam_in = int(input('Enter combined family annual income(must be more than $19,500): $'))
# Check user input
while fam_in <= 19500:
    fam_in = int(input('INVAILD INPUT - Enter combined family annual income(MUST BE MORE THAN $19,500): $'))

# Input family expenses
fam_ex = int(input('Enter annual family expense(Must be more than $0): $'))
# Check user input
while fam_ex < 1:
    fam_ex = float(input('INVAILD INPUT - Enter annual family expense(MUST BE MORE THAN $0): $'))

# Input if user has owned house - bool variable 
ownHouse = input('Have or are you owning a house? (y-yes, n-no): ').lower()
# Check user input
while ownHouse != 'y' and ownHouse != 'n':
    ownHouse = input('INVAILD INPUT - Have or are you owning a house? (y-yes, n-no): ').lower()


# Calculation of savings
fam_sav = fam_in - fam_ex

# Check if user input
if fam_in > 125000 and fam_sav >= 25000 and ownHouse == 'n':
    print(true)
else:
    print(false)


