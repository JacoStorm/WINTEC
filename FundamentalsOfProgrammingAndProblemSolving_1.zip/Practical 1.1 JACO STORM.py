'''
Author: Jaco Storm 15435194

Pledge of Homour: I pledge by honout that this program is solely my own work.

Program ONE
Description: This program returns a session when given the monthby the user in
the form of the first three leters of the month
'''


# Gets data from user
resp = input('Please enter a month (First 3 letters only): ').lower()

# Check which session corrospond with the month
if resp == 'dec' or resp == 'jan' or resp == 'feb':
    print(resp,"would be super sunny Summer.")
    
elif resp == 'mar' or resp == 'apr' or resp == 'may':
    print(resp,"would be a beautiful Autumn.")

elif resp == 'jun' or resp == 'jul' or resp == 'aug':
    print(resp,"is the time to snuggle during Winter.")

elif resp == 'sep' or resp == 'oct' or resp == 'nov':
    print('Kitesurfing is best in',resp,'during Spring')

else: # User input checking
    print(resp, "the mythical month!")
    print('Please try again! :)')

# End of program note
print('Thanks for playing')
