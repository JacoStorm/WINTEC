'''
Author: Jaco Storm 15435194

Pledge of Homour: I pledge by honout that this program is solely my own work.

Assignment
Program Two
Description: Reads information regarding company records from data and organises it in a reading friendly
format.

'''

from datetime import datetime

def readdata(filename):
    '''
        Reads file name passed as parameter and returns a list or records
    '''
    print('*'*18,'Collecting Data','*'*18)
    print()
    # Setting up variables
    date_fm = '%d-%m-%Y'
    
    # Set up empty container
    data = []
    with open (filename,'r') as readfile:
        for line in readfile:
            a_line = line.split(',')
            date_str = a_line[6].strip()
            date_obj = datetime.strptime(date_str,date_fm)
            rec = [a_line[0], a_line[1], float(a_line[2]), float(a_line[3]), int(a_line[4]), a_line[5], date_obj]
            data.append(rec)
            
    print('Done.\n\n')
    #print(data)
    return data

def print_all_records(data):
    '''
        Displays list passed to fucntions in easy to read format
    '''
    
    # Loading info
    print('*'*18,'Printing All Records','*'*18)
    print()
    # Creating Template to print on
    temp = '{0:20}{1:22}{2:10.2f}{3:17}{4:12}{5:15}{6:10}'
    dateTemp = '%d-%m-%Y'

    for count in data:
        row = temp.format(count[0],count[1],float(count[2]),float(count[3]),int(count[4]),count[5],datetime.strftime(count[6],dateTemp))
        print(row)
    print()
    print()

def print_positive_growth(data):
    ''' function searches through list to find and display all positive revenues '''
    # Setting up templates
    temp = '{0:20}{1:22}{2:10.2f}{3:17}{4:12}{5:15}{6:10}'
    dateTemp = '%d-%m-%Y'
    rec_found = None # 'None' is a special value (as a maker)
    for rec in data:
        if rec[3] >= 0:
            row = temp.format(rec[0],rec[1],float(rec[2]),float(rec[3]),int(rec[4]),rec[5],datetime.strftime(rec[6],dateTemp))
            print(row)
    print()
    print()
    
def query_record_by_date(data):
    '''
        Function asked user for a date and displays entered date in respect to list data
    '''
    # Setting up templates
    dateTemp = '%d-%m-%Y'
    temp = '{0:20}{1:10.2f}'
    # Get date flag
    datestr = input('Enter a date(dd mm yyyy): ')
    # Convert string to object
    dateobj = datetime.strptime(datestr,'%d %m %Y')
    rec_found = None # 'None' is a special value (as a maker)
    for rec in data:
        if dateobj == rec[6]: #rec[6] is the date object of each records
            rec_found = rec #update rec_found with the matching 'rec'
            row = temp.format(rec[0],float(rec[2]))
            print(row)

    if rec_found == None:
        print('No matching record found')

def query_total_revenue_by_industry(data):
    # Setting up templates
    temp = '{0:20}{1:22}{2:10.2f}{3:17}{4:12}{5:15}{6:10}'
    dateTemp = '%d-%m-%Y'
    # Get date flag
    industry = input('Enter industry name: ')
    rec_found = None # 'None' is a special value (as a maker)
    totalRev = 0 # Total Revenue placeholder
    count = 0 # Count number of matches found
    for rec in data:
        # Search through every rec
        if industry == rec[1]:
            rec_found = rec #update rec_found with the matching 'rec'
            totalRev += int(rec_found[2])
            count += 1

    #Calculate Revenue Aveage
    ave = totalRev/count

    # Check if match found
    if rec_found == None:
        # Display expection
        print('No match returned for:',industry)
    else:
        # Display positive result
        print()
        print()
        print('Total revenue (USD) for',industry,':',totalRev)
        print('Total revenue (USD) for',industry,':',ave)     
    
    

def main():
    data = readdata('data.txt')
    print_all_records(data)
    print_positive_growth(data)
    query_record_by_date(data)
    query_total_revenue_by_industry(data)
    #count_companies_between_dates(data)
    #writedata('backup.txt',data)

main()
    
