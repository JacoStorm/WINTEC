'''
Author: Jaco Storm 15435194

Pledge of Homour: I pledge by honout that this program is solely my own work.

Assignment
Program One
Description: draws a pattern which displays a medal ceremony

'''

from turtle import*

def move_to(x, y):
    ''' x and y are the coordinates of the point to move the drawing pen
        without drawing on canvas
    '''
    #Move pen without drawing
    pu()
    goto(x,y)
    pd()

def draw_head(x,y,radius):
    '''
        x and y represent start point for the circle and r represent the radius
    '''
    # Draw a head
    move_to(x,y)
    setheading(0)
    circle(radius)

def draw_line(x1, y1,x2 ,y2):
    '''
        first x,y represent the start of the line and the second respresent the last
    '''
    # Draw a line
    move_to(x1,y1)
    goto(x2,y2)
    
def draw_block(x,y,height,width,colour):
    '''
        x and y represent bottum left corner of rectangle where high represent
        height and wide represent width and col represent colour
    '''
    #Draw a block with parameters 
    move_to(x,y)
    begin_fill()
    fillcolor(colour)
    setheading(0)
    forward(width)
    left(90)
    forward(height)
    left(90)
    forward(width)
    left(90)
    forward(height)
    end_fill()

def draw_podium(winning_colour, second_colour, third_colour):
    '''
        Draw podium with three respective colour parameters which include
        winning_col as win_col, second_colour as sec_col and third colour
        as thi_col
    '''
    # Draw podium
    draw_block(60,0,90,60,winning_colour)
    draw_block(0,0,60,60,second_colour)
    draw_block(120,0,40,60,third_colour)

def draw_winner(colour):
    '''
        draws the winner stickman with a phased colour
    '''

    draw_head(90,160,10)
    #Draw arms
    draw_line(90,140,60,180)
    draw_line(90,140,120,180)
    #Draw legs
    draw_line(80,120,80,90)
    draw_line(100,120,100,90)
    #Draw body
    draw_block(70,120,40,40,colour)
    
    
def draw_second(colour):
    '''
        draws the winner stickman with a phased colour
    '''
    draw_head(30,125,10)
    #Draw arms
    draw_line(30,110,0,130)
    draw_line(30,110,60,130)
    #Draw legs
    draw_line(20,90,20,60)
    draw_line(40,90,40,60)
    #Draw body
    move_to(10,90)
    begin_fill()
    fillcolor(colour)
    setheading(0)
    fd(40)
    left(120)
    fd(40)
    left(120)
    fd(40)
    end_fill()

def draw_third(colour):
    '''
        draws the winner stickman with a phased colour
    '''
    draw_head(150,90,10)
    #Draw arms
    draw_line(150,70,120,120)
    draw_line(150,70,180,120)
    #Draw legs
    draw_line(140,70,140,40)
    draw_line(160,70,160,40)
    #Draw body
    move_to(130,90)
    begin_fill()
    fillcolor(colour)
    setheading(0)
    fd(40)
    right(120)
    fd(40)
    right(120)
    fd(40)
    end_fill()
    
def main():
    speed(10)
    pensize(3)
    pencolor('black')

    winner_colour = 'red'
    second_colour = 'orange'
    third_colour = 'purple'
    draw_podium(winner_colour, second_colour, third_colour)
    draw_winner(winner_colour)
    draw_second(second_colour)
    draw_third(third_colour)

    hideturtle()
    exitonclick()
    
main()
