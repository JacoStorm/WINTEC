﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;


namespace DataStruct_Assignement_1c
{
    class Program
    {

        // Jaco Strom
        // Data Structure 
        // Assignment 1c

        // Instance variables
        static string filePath = "C:\\Users\\JacoS\\Desktop\\DataStructures\\DataStruc_HastTable_TestData_Quick.txt";
        static string[] words;
        static Hashtable Table = new Hashtable();

        
        static void Main(string[] args)
        {
            LoadData(filePath);
            PrintMax(Table);
            Console.ReadKey();
        }

        // Part B:  INSERT Ave Case: O(181)  |  Worst Case: O(n)
        private static void LoadData(string conn)
        {
            // Get file content
            string wholeText = File.ReadAllText(conn);
            // Divide entire text into seperate words
            words = wholeText.Split(' ', '.', ':', ';', '?', '!', ',', '\n','\r'); // try and find other way off getting ride of empty space char
            //words = test.Split(new string[] { "\n", "\r\n" }, StringSplitOptions.RemoveEmptyEntries);
            int countArray = words.Count();
            
            // For each word in array
            foreach (string item in words)
            {
                string fmtItem2 = item.ToString().Trim().Trim('\r').ToLower();  // try .EndsWith(',','.');
                                                                                //string fmtItem = words[int.Parse(item)].ToLower();

                // Check if word is new, if true add to hashtable 
                if (CheckHash(Table, fmtItem2))
                {
                    int count = 0;
                    Table.Add(fmtItem2, count);     // Add to hash as new word and assign 1 as visible aid
                    Console.WriteLine("{0}\tAdded", fmtItem2.ToString());     // Show result in console window for problem solving
                }
                else
                {
                    Table[item] = 1 + (int)Table[fmtItem2];     // Increment count with 1 to count word freqency 
                    Console.WriteLine("{0}\tMatch Found", fmtItem2.ToString());
                }
            }
            if (Table.ContainsKey("")) Table.Remove("");
            
        }

        private static bool CheckHash(Hashtable hash, string testWord)
        {
            bool flag = true;
            // Check if the hash contains the key
            if (hash.ContainsKey(testWord))
            {
                flag = false;
            }
            return flag;
        }

        // Part B:  INSERT Ave Case: O(n)  |  Worst Case: O(n)
        private static void PrintMax(Hashtable hash)
        {
            // Instance variables
            int max = 0;
            int count = 0;
            string word = ""; 
            // Cycle through all entries in hash
            foreach (DictionaryEntry item in hash)
            {
                // Extract the value of particular entry
                count = int.Parse(item.Value.ToString());
                // Check for highest count entry
                if (max < count)
                {
                    // Assign new max and save work
                    word = item.Key.ToString().ToUpper();
                    max = count;
                }
            }
            // Print findigns
            Console.WriteLine("\"{0}\" with {1} is the most freqent word.", word, max.ToString());
        }
    }
}
