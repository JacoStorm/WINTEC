﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace Week1GUI
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        /*
            Task: write a GUI application where the user enters two numbers in two textboxes. 
            Then, the application displays all the prime numbers between these two numbers in another textbox. 
            It displays five numbers each line.
        */

        /// <summary>
        /// Button to display primeNumbers between two given Int values
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void primeFinderButton_Click(object sender, EventArgs e)
        {
            try
            {
                // Clear any existing searches.
                primeNumTextBox.Clear();

                // Get values 
                int num1 = int.Parse(Num1TextBox.Text);
                int num2 = int.Parse(num2TextBox.Text);

                // Counter holding of number results
                int numCount = 0;
                   
                //Loop through the two given number or check which are prime numbers
                for (int i = num1; i <= num2; i++)
                {
                    // Check if number is prime or not
                    if(IsPrime(i) == true)
                    {
                        // change font ,size and colour for extra points - I remembered your challenge Sir ;) 
                        Font extraMarks = new Font("Times New Roman", 20);
                        primeNumTextBox.Font = extraMarks;
                        primeNumTextBox.ForeColor = Color.Teal;
                        // If result count is more than 5, jump to new line.
                        if (numCount <= 4)
                        {
                            // Print new prime number into textbox and increment numCount
                            primeNumTextBox.AppendText(i + "  ");
                            numCount++;
                        }
                        else
                        {
                            // Drop a line, print prime number and reset counter.
                            primeNumTextBox.AppendText("\r\n");
                            primeNumTextBox.AppendText(i + "  ");
                            numCount = 1;
                        }
                    }
                }
            }
            // Error handling 
            catch (Exception)
            {
                throw;
            }
        }

        /// <summary>
        /// Boolean function returning if Int parsed to method is a prime number or not.
        /// </summary>
        /// <param name="num">Int to be test for prime number status</param>
        /// <returns>True if Int is primeNumber</returns>
        private bool IsPrime(int num)
        {
            if ((num%2)==0)
            {
                return false;
            }
            for (int i = 2; i < num; i++)
            {
                if ((num%i)==0)
                {
                    return false;
                }
            }
            return true;
        }

       
    }
}
