﻿namespace Week1GUI
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.num1label = new System.Windows.Forms.Label();
            this.num2Label = new System.Windows.Forms.Label();
            this.Num1TextBox = new System.Windows.Forms.TextBox();
            this.num2TextBox = new System.Windows.Forms.TextBox();
            this.primeFinderButton = new System.Windows.Forms.Button();
            this.primeNumTextBox = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // num1label
            // 
            this.num1label.AutoSize = true;
            this.num1label.Location = new System.Drawing.Point(16, 31);
            this.num1label.Name = "num1label";
            this.num1label.Size = new System.Drawing.Size(105, 25);
            this.num1label.TabIndex = 1;
            this.num1label.Text = "Number 1";
            // 
            // num2Label
            // 
            this.num2Label.AutoSize = true;
            this.num2Label.Location = new System.Drawing.Point(16, 112);
            this.num2Label.Name = "num2Label";
            this.num2Label.Size = new System.Drawing.Size(105, 25);
            this.num2Label.TabIndex = 2;
            this.num2Label.Text = "Number 2";
            // 
            // Num1TextBox
            // 
            this.Num1TextBox.Location = new System.Drawing.Point(121, 25);
            this.Num1TextBox.Name = "Num1TextBox";
            this.Num1TextBox.Size = new System.Drawing.Size(167, 31);
            this.Num1TextBox.TabIndex = 3;
            // 
            // num2TextBox
            // 
            this.num2TextBox.Location = new System.Drawing.Point(121, 106);
            this.num2TextBox.Name = "num2TextBox";
            this.num2TextBox.Size = new System.Drawing.Size(167, 31);
            this.num2TextBox.TabIndex = 4;
            // 
            // primeFinderButton
            // 
            this.primeFinderButton.Location = new System.Drawing.Point(21, 190);
            this.primeFinderButton.Name = "primeFinderButton";
            this.primeFinderButton.Size = new System.Drawing.Size(248, 58);
            this.primeFinderButton.TabIndex = 7;
            this.primeFinderButton.Text = "Find Prime Number";
            this.primeFinderButton.UseVisualStyleBackColor = true;
            this.primeFinderButton.Click += new System.EventHandler(this.primeFinderButton_Click);
            // 
            // primeNumTextBox
            // 
            this.primeNumTextBox.AcceptsReturn = true;
            this.primeNumTextBox.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.primeNumTextBox.Location = new System.Drawing.Point(326, 25);
            this.primeNumTextBox.Multiline = true;
            this.primeNumTextBox.Name = "primeNumTextBox";
            this.primeNumTextBox.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.primeNumTextBox.Size = new System.Drawing.Size(622, 470);
            this.primeNumTextBox.TabIndex = 8;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.ClientSize = new System.Drawing.Size(972, 578);
            this.Controls.Add(this.primeNumTextBox);
            this.Controls.Add(this.primeFinderButton);
            this.Controls.Add(this.num2TextBox);
            this.Controls.Add(this.Num1TextBox);
            this.Controls.Add(this.num2Label);
            this.Controls.Add(this.num1label);
            this.Margin = new System.Windows.Forms.Padding(6);
            this.Name = "Form1";
            this.Text = "Adding Machine";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label num1label;
        private System.Windows.Forms.Label num2Label;
        private System.Windows.Forms.TextBox Num1TextBox;
        private System.Windows.Forms.TextBox num2TextBox;
        private System.Windows.Forms.Button primeFinderButton;
        private System.Windows.Forms.TextBox primeNumTextBox;
    }
}

