﻿using System;
using System.Collections.Generic;
using System.Data.OleDb;
using System.Drawing;

namespace AppDev_FinalFarm
{
         /*
            INFO 609: Application Developement
            Final Overall Project

            Author: Jaco Storm
            Application Name: Farm Management Tool
         */
    public partial class Form1 : System.Windows.Forms.Form
    {
        // Connection details 
        String conn_string = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=c:\\Users\\JacoS\\Desktop\\App Dev\\FarmInfomation[DONT MOVE].accdb;Persist Security Info=False;";
        OleDbConnection conn = null;


        // Dictionary to hold all animal details
        Dictionary<int, Animals> fm = new Dictionary<int, Animals>();

        // Dictionary to hold all commodities
        //Dictionary<string, double> Com = new Dictionary<string, double>();
        Commodies Com = new Commodies();

        public Form1()
        {
            InitializeComponent();
            // Load animals and commodity
            LoadData(conn_string);
        }

        /// <summary>
        /// Loads data into the program from MS Access
        /// </summary>
        /// <param name="conn_string">Connection string</param>
        private void LoadData(string conn_string)
        {
            try
            {
                // create new OLE connection objects.
                conn = new OleDbConnection(conn_string);
                conn.Open();

                //Populate Cow Dictionary.  R
                OleDbCommand cmd = new OleDbCommand("select * from Cows");
                cmd.Connection = conn;

                // Cycles through every object
                using (OleDbDataReader reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        // Add to dictionary
                        Cow tmpCow = new Cow(reader);
                        fm.Add(tmpCow.ID, tmpCow);
                    }
                }

                //Populate Sheep Dictionary.  
                cmd = new OleDbCommand("select * from Sheep", conn);
                using (OleDbDataReader reader = cmd.ExecuteReader())
                {
                    // Cycle through each object
                    while (reader.Read())
                    {
                        // Add to dictionary
                        Sheep tmpSheep = new Sheep(reader);
                        fm.Add(tmpSheep.ID, tmpSheep);
                    }
                }

                //Populate Dog hashtable
                cmd = new OleDbCommand("select * from Dogs", conn);
                using (OleDbDataReader reader = cmd.ExecuteReader())
                {
                    // Cycle through each object
                    while (reader.Read())
                    {
                        // Add to dictionary
                        Dog tmpDog = new Dog(reader);
                        fm.Add(tmpDog.ID, tmpDog);
                    }
                }

                //Populate Goat hashtable
                cmd = new OleDbCommand("select * from Goats", conn);
                using (OleDbDataReader reader = cmd.ExecuteReader())
                {
                    // Cycle through each object
                    while (reader.Read())
                    {
                        // Add to dictionary
                        Goat tmpGoat = new Goat(reader);
                        fm.Add(tmpGoat.ID, tmpGoat);
                    }
                }

                // Close connection
                conn.Close();


                //loadCommodity();

                // Format output
                connState.ForeColor = Color.Teal;
                string trueState = "Database connected...";
                connState.Text = trueState;
            }
            catch 
            {
                // Format and return error
                string error = "Database Connection FAIL     Contact your developer";
                messageLabel.ForeColor = Color.Red;
                messageLabel.Text = error;
            }
        }

        /// <summary>
        /// Loads commodity prices from MS Access
        /// </summary>
        private void loadCommodity()
        {
            // Create new set of prices
            double[] prices = new double[6];

            // Populate the price table 
            string q = "Select * from prices";
            OleDbCommand cmd = new OleDbCommand(q, conn);

            int count = 0;
            conn.Open();

            // Cycle through each row
            using (OleDbDataReader reader = cmd.ExecuteReader())
            {
                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        // gets and counts rows.
                        string[] row = GetRows(reader);
                        prices[count] = Convert.ToDouble(row[1]);
                        count++;
                    }

                    // Add rows to Commodies
                    Com.GoatMilkPrice = prices[0];
                    Com.WoolPrice = prices[1];
                    Com.WaterPrice = prices[2];
                    Com.GovTax = prices[3];
                    Com.JerseyTax = prices[4];
                    Com.CowMilkPrice = prices[5];
                }
            }
            conn.Close();   // Close connection
        }

        /// <summary>
        /// Gets each value with commodity table
        /// </summary>
        /// <param name="reader"></param>
        /// <returns></returns>
        private string[] GetRows(OleDbDataReader reader)
        {
            int col = reader.FieldCount;        
            object[] items = new object[col];

            reader.GetValues(items);
            string[] row = new string[col];

            for (int i = 0; i < col; i++)
            {
                row[i] = items[i].ToString();
            }

            return row;
        }

        /// <summary>
        /// Gets and displays profits
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void TotalProfitButton_Click(object sender, EventArgs e)
        {   
            // Format text
            string heading = "Total Profit";
            header(heading);
            string str = "Total Profit:\t";
            // get report data
            double profit = Reports.CalProfit(fm);
            // Display report
            ResultBox.AppendText(str + profit);
            NewLine();
        }

        /// <summary>
        /// Gets and displays total milk produced
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void GetMilkButton_Click(object sender, EventArgs e)
        {
            // format text
            string heading = "Total Milk Produced";
            header(heading);
            string str = "Total Milk Produced:\t";
            // get report data
            double milk = Reports.getAllMilk(fm);
            // Display report
            ResultBox.AppendText(str + milk);
            NewLine();
        }

        /// <summary>
        /// Gets and displays monthly tax
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void MonthlyTaxButton_Click(object sender, EventArgs e)
        {
            // format text
            string heading = "Monthly Tax Expenses";
            header(heading);
            string str = "Total Monthly Tax:\t";
            // get data
            double tax = Reports.MonthlyTax(fm);
            // display report
            ResultBox.AppendText(str + tax);
            NewLine();
        }

        /// <summary>
        /// Gets and displays average age of farm animals
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void AveAgeButton_Click(object sender, EventArgs e)
        {
            string heading = "Average Animal Age";
            header(heading);
            string str = "Average Animal Age:\t";
            double age = Reports.AveAge(fm);
            ResultBox.AppendText(str + age);
            NewLine();
        }

        /// <summary>
        /// Gets and displays profit ratio of milk and wool
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void MilkvsWoolButton_Click(object sender, EventArgs e)
        {
            string heading = "Profits for milk vs profits for wool";
            header(heading);
            string Milkstr = "Milk Profits:\t";
            string WoolStr = "Wool Profits:\t";
            string ResultStr = "Wool vs Milk:\t";
            double wool = Reports.WoolProfifts(fm);
            double milk = Reports.MilkProfifts(fm);
            double vs = milk - wool;
            ResultBox.AppendText(Milkstr + milk);
            NewLine();
            ResultBox.AppendText(WoolStr + wool);
            NewLine();
            ResultBox.AppendText(ResultStr + vs);
            NewLine();
        }

        /// <summary>
        /// Gets and displays ratio of dogs to rest of farm animals
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void DogRatioButton_Click(object sender, EventArgs e)
        {
            string heading = "Dogs to Livestock ratio";
            header(heading);

            string Dogstr = "Dog Expenses:\t";
            string SumStr = "Total Expenses:\t";
            string ResultStr = "Total : Dog = \t";
            double dogEx = Reports.GetDogExp(fm);
            double sumEx = Reports.GetExpense(fm);
            double remainder = sumEx - dogEx;

            ResultBox.AppendText(Dogstr + dogEx);
            NewLine();
            ResultBox.AppendText(SumStr + sumEx);
            NewLine();
            ResultBox.AppendText(ResultStr + remainder + " : " + dogEx);
            NewLine();
        }

        /// <summary>
        /// Gets and displays all red animals
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void RedAnimals_Click(object sender, EventArgs e)
        {
            string heading = "Jersy Profit";
            header(heading);

            string redStr = "Red livestock:\t";
            string SumStr = "Total number of livestock:\t";
            string ResultStr = "Total : Red Livestock = \t";
            int redLiveS = Reports.GetRedLivestock(fm);
            int sumLiveS = Reports.Count(fm);
            double remainder = sumLiveS - redLiveS;

            ResultBox.AppendText(redStr + redLiveS);
            NewLine();
            ResultBox.AppendText(SumStr + sumLiveS);
            NewLine();
            ResultBox.AppendText(ResultStr + remainder + " : " + redLiveS);
            NewLine();
        }

        /// <summary>
        /// Gets and displays profits from jersy animals
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void JerseyProfitButton_Click(object sender, EventArgs e)
        {
            string heading = "Jersy Profit";
            header(heading);
            string str = "Total Jersy Profit:\t";
            double sum = Reports.GetJersyProfit(fm);
            ResultBox.AppendText(str + sum);
            NewLine();
        }

        /// <summary>
        /// Gets and displays tax expenses of jersy cow
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void JerseyTaxButton_Click(object sender, EventArgs e)
        {
            string heading = "Jersy Tax Expenses";
            header(heading);
            string str = "Total Jersy Tax:\t";
            double tax = Reports.GetJersyTax(fm);
            ResultBox.AppendText(str + tax);
            NewLine();
        }

        /// <summary>
        /// Create a header within each method
        /// </summary>
        /// <param name="query"></param>
        private void header(string query)
        {
            NewLine();
            string heading = String.Format("==============   {0}   ==============", query);
            ResultBox.AppendText(heading);
            NewLine();
        }

        /// <summary>
        /// Create a new line in textbox within each method
        /// </summary>
        /// <param name="query"></param>
        private void NewLine()
        {
            ResultBox.AppendText(Environment.NewLine);
        }

        /// <summary>
        /// Find a record with either age or id number
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Find_Record_Click(object sender, EventArgs e)
        {
            try
            {
                if (find_age_Radio.Checked)
                {
                    messageLabel.Text = "";
                    int range = Reports.GetAgeRange(fm, int.Parse(IDBox.Text));
                    int sum = Reports.Count(fm);
                    int remain = sum - range;

                    string query = "ANIMALS ABOVE SELECTED AGE";
                    header(query);
                    
                    string ResultStr = "Total vs Selected age:\t";
                    NewLine();
                    ResultBox.AppendText(ResultStr + range + " : " + remain);
                    NewLine();
                }
                else if (find_ID_Radio.Checked)
                {
                    messageLabel.Text = "";
                    try
                    {
                        if (IDBox.Text == null)
                        {
                            messageLabel.Text = "Please enter a ID number";
                        }
                        else
                        {
                            header("ID SEARCH");
                            foreach (KeyValuePair<int, Animals> item in fm)
                            {
                                if (item.Key == int.Parse(IDBox.Text))
                                {
                                    ResultBox.AppendText(item.Value.getProp());
                                }
                            }
                            NewLine();
                        }
                        
                    }
                    catch 
                    {
                        string error = "Please try again";
                        messageLabel.ForeColor = Color.Red;
                        messageLabel.Text = error;
                        IDBox.Clear();
                        IDBox.Focus();
                    }
                }
                else
                {
                    string error = "Please check atleast one option";
                    messageLabel.ForeColor = Color.Red;
                    messageLabel.Text = error;
                    IDBox.Focus();
                }
            }
            catch
            {
                string error = "Please try again";
                messageLabel.ForeColor = Color.Red;
                messageLabel.Text = error;
                IDBox.Clear();
                IDBox.Focus();
            }
        }
    }
}
