﻿namespace AppDev_FinalFarm
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.IDBox = new System.Windows.Forms.TextBox();
            this.ResultBox = new System.Windows.Forms.TextBox();
            this.find_ID_Radio = new System.Windows.Forms.RadioButton();
            this.find_age_Radio = new System.Windows.Forms.RadioButton();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.messageLabel = new System.Windows.Forms.Label();
            this.Find_Record = new System.Windows.Forms.Button();
            this.connState = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.label2 = new System.Windows.Forms.Label();
            this.JerseyTaxButton = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.JerseyProfitButton = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.RedAnimals = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.DogRatioButton = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.MilkvsWoolButton = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.AveAgeButton = new System.Windows.Forms.Button();
            this.label7 = new System.Windows.Forms.Label();
            this.MonthlyTaxButton = new System.Windows.Forms.Button();
            this.label8 = new System.Windows.Forms.Label();
            this.GetMilkButton = new System.Windows.Forms.Button();
            this.label9 = new System.Windows.Forms.Label();
            this.TotalProfitButton = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // IDBox
            // 
            this.IDBox.Location = new System.Drawing.Point(266, 28);
            this.IDBox.Multiline = true;
            this.IDBox.Name = "IDBox";
            this.IDBox.Size = new System.Drawing.Size(229, 80);
            this.IDBox.TabIndex = 0;
            // 
            // ResultBox
            // 
            this.ResultBox.Location = new System.Drawing.Point(12, 567);
            this.ResultBox.Multiline = true;
            this.ResultBox.Name = "ResultBox";
            this.ResultBox.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.ResultBox.Size = new System.Drawing.Size(1553, 457);
            this.ResultBox.TabIndex = 1;
            // 
            // find_ID_Radio
            // 
            this.find_ID_Radio.AutoSize = true;
            this.find_ID_Radio.Location = new System.Drawing.Point(16, 30);
            this.find_ID_Radio.Name = "find_ID_Radio";
            this.find_ID_Radio.Size = new System.Drawing.Size(216, 29);
            this.find_ID_Radio.TabIndex = 7;
            this.find_ID_Radio.TabStop = true;
            this.find_ID_Radio.Text = "Find Animal via ID";
            this.find_ID_Radio.UseVisualStyleBackColor = true;
            // 
            // find_age_Radio
            // 
            this.find_age_Radio.AutoSize = true;
            this.find_age_Radio.Location = new System.Drawing.Point(16, 79);
            this.find_age_Radio.Name = "find_age_Radio";
            this.find_age_Radio.Size = new System.Drawing.Size(189, 29);
            this.find_age_Radio.TabIndex = 8;
            this.find_age_Radio.TabStop = true;
            this.find_age_Radio.Text = "Search via Age";
            this.find_age_Radio.UseVisualStyleBackColor = true;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.messageLabel);
            this.groupBox1.Controls.Add(this.Find_Record);
            this.groupBox1.Controls.Add(this.find_ID_Radio);
            this.groupBox1.Controls.Add(this.find_age_Radio);
            this.groupBox1.Controls.Add(this.IDBox);
            this.groupBox1.Location = new System.Drawing.Point(22, 48);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(753, 190);
            this.groupBox1.TabIndex = 9;
            this.groupBox1.TabStop = false;
            // 
            // messageLabel
            // 
            this.messageLabel.AutoSize = true;
            this.messageLabel.ForeColor = System.Drawing.Color.DarkRed;
            this.messageLabel.Location = new System.Drawing.Point(26, 131);
            this.messageLabel.Name = "messageLabel";
            this.messageLabel.Size = new System.Drawing.Size(0, 25);
            this.messageLabel.TabIndex = 10;
            // 
            // Find_Record
            // 
            this.Find_Record.Location = new System.Drawing.Point(533, 30);
            this.Find_Record.Name = "Find_Record";
            this.Find_Record.Size = new System.Drawing.Size(155, 78);
            this.Find_Record.TabIndex = 9;
            this.Find_Record.Text = "Find ID";
            this.Find_Record.UseVisualStyleBackColor = true;
            this.Find_Record.Click += new System.EventHandler(this.Find_Record_Click);
            // 
            // connState
            // 
            this.connState.AutoSize = true;
            this.connState.Location = new System.Drawing.Point(7, 9);
            this.connState.Name = "connState";
            this.connState.Size = new System.Drawing.Size(0, 25);
            this.connState.TabIndex = 10;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.label9);
            this.groupBox2.Controls.Add(this.TotalProfitButton);
            this.groupBox2.Controls.Add(this.label8);
            this.groupBox2.Controls.Add(this.GetMilkButton);
            this.groupBox2.Controls.Add(this.label7);
            this.groupBox2.Controls.Add(this.MonthlyTaxButton);
            this.groupBox2.Controls.Add(this.label6);
            this.groupBox2.Controls.Add(this.AveAgeButton);
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Controls.Add(this.JerseyTaxButton);
            this.groupBox2.Controls.Add(this.label1);
            this.groupBox2.Controls.Add(this.JerseyProfitButton);
            this.groupBox2.Location = new System.Drawing.Point(22, 273);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(1527, 196);
            this.groupBox2.TabIndex = 11;
            this.groupBox2.TabStop = false;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(159, 31);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(106, 25);
            this.label2.TabIndex = 3;
            this.label2.Text = "Jersy Tax";
            // 
            // JerseyTaxButton
            // 
            this.JerseyTaxButton.Location = new System.Drawing.Point(159, 70);
            this.JerseyTaxButton.Name = "JerseyTaxButton";
            this.JerseyTaxButton.Size = new System.Drawing.Size(125, 81);
            this.JerseyTaxButton.TabIndex = 2;
            this.JerseyTaxButton.Text = "Display Tax";
            this.JerseyTaxButton.UseVisualStyleBackColor = true;
            this.JerseyTaxButton.Click += new System.EventHandler(this.JerseyTaxButton_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(16, 31);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(120, 25);
            this.label1.TabIndex = 1;
            this.label1.Text = "Jersy Profit";
            // 
            // JerseyProfitButton
            // 
            this.JerseyProfitButton.Location = new System.Drawing.Point(16, 70);
            this.JerseyProfitButton.Name = "JerseyProfitButton";
            this.JerseyProfitButton.Size = new System.Drawing.Size(125, 81);
            this.JerseyProfitButton.TabIndex = 0;
            this.JerseyProfitButton.Text = "Display Profit";
            this.JerseyProfitButton.UseVisualStyleBackColor = true;
            this.JerseyProfitButton.Click += new System.EventHandler(this.JerseyProfitButton_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(799, 62);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(232, 25);
            this.label3.TabIndex = 5;
            this.label3.Text = "Red Coloured Animals ";
            // 
            // RedAnimals
            // 
            this.RedAnimals.Location = new System.Drawing.Point(847, 101);
            this.RedAnimals.Name = "RedAnimals";
            this.RedAnimals.Size = new System.Drawing.Size(125, 118);
            this.RedAnimals.TabIndex = 4;
            this.RedAnimals.Text = "Display Red Animals";
            this.RedAnimals.UseVisualStyleBackColor = true;
            this.RedAnimals.Click += new System.EventHandler(this.RedAnimals_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(1053, 62);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(260, 25);
            this.label4.TabIndex = 13;
            this.label4.Text = "Cost dog to livestock ratio";
            // 
            // DogRatioButton
            // 
            this.DogRatioButton.Location = new System.Drawing.Point(1131, 101);
            this.DogRatioButton.Name = "DogRatioButton";
            this.DogRatioButton.Size = new System.Drawing.Size(125, 118);
            this.DogRatioButton.TabIndex = 12;
            this.DogRatioButton.Text = "Find Ratio";
            this.DogRatioButton.UseVisualStyleBackColor = true;
            this.DogRatioButton.Click += new System.EventHandler(this.DogRatioButton_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(1358, 62);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(207, 25);
            this.label5.TabIndex = 15;
            this.label5.Text = "Profits: Wool vs Milk";
            // 
            // MilkvsWoolButton
            // 
            this.MilkvsWoolButton.Location = new System.Drawing.Point(1397, 101);
            this.MilkvsWoolButton.Name = "MilkvsWoolButton";
            this.MilkvsWoolButton.Size = new System.Drawing.Size(125, 118);
            this.MilkvsWoolButton.TabIndex = 14;
            this.MilkvsWoolButton.Text = "Find Ratio";
            this.MilkvsWoolButton.UseVisualStyleBackColor = true;
            this.MilkvsWoolButton.Click += new System.EventHandler(this.MilkvsWoolButton_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(301, 31);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(136, 25);
            this.label6.TabIndex = 5;
            this.label6.Text = "Average Age";
            // 
            // AveAgeButton
            // 
            this.AveAgeButton.Location = new System.Drawing.Point(301, 70);
            this.AveAgeButton.Name = "AveAgeButton";
            this.AveAgeButton.Size = new System.Drawing.Size(125, 81);
            this.AveAgeButton.TabIndex = 4;
            this.AveAgeButton.Text = "Display Ave Age";
            this.AveAgeButton.UseVisualStyleBackColor = true;
            this.AveAgeButton.Click += new System.EventHandler(this.AveAgeButton_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(449, 31);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(220, 25);
            this.label7.TabIndex = 7;
            this.label7.Text = "Monthly Tax Expense";
            // 
            // MonthlyTaxButton
            // 
            this.MonthlyTaxButton.Location = new System.Drawing.Point(484, 70);
            this.MonthlyTaxButton.Name = "MonthlyTaxButton";
            this.MonthlyTaxButton.Size = new System.Drawing.Size(125, 81);
            this.MonthlyTaxButton.TabIndex = 6;
            this.MonthlyTaxButton.Text = "Display Tax";
            this.MonthlyTaxButton.UseVisualStyleBackColor = true;
            this.MonthlyTaxButton.Click += new System.EventHandler(this.MonthlyTaxButton_Click);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(706, 31);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(149, 25);
            this.label8.TabIndex = 9;
            this.label8.Text = "Milk Produced";
            // 
            // GetMilkButton
            // 
            this.GetMilkButton.Location = new System.Drawing.Point(720, 70);
            this.GetMilkButton.Name = "GetMilkButton";
            this.GetMilkButton.Size = new System.Drawing.Size(125, 99);
            this.GetMilkButton.TabIndex = 8;
            this.GetMilkButton.Text = "Display Milk Production";
            this.GetMilkButton.UseVisualStyleBackColor = true;
            this.GetMilkButton.Click += new System.EventHandler(this.GetMilkButton_Click);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(888, 31);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(116, 25);
            this.label9.TabIndex = 11;
            this.label9.Text = "Total Profit";
            // 
            // TotalProfitButton
            // 
            this.TotalProfitButton.Location = new System.Drawing.Point(891, 70);
            this.TotalProfitButton.Name = "TotalProfitButton";
            this.TotalProfitButton.Size = new System.Drawing.Size(125, 81);
            this.TotalProfitButton.TabIndex = 10;
            this.TotalProfitButton.Text = "Display Total Profit";
            this.TotalProfitButton.UseVisualStyleBackColor = true;
            this.TotalProfitButton.Click += new System.EventHandler(this.TotalProfitButton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.ClientSize = new System.Drawing.Size(1588, 1059);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.MilkvsWoolButton);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.DogRatioButton);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.RedAnimals);
            this.Controls.Add(this.connState);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.ResultBox);
            this.Name = "Form1";
            this.Text = "Form1";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox IDBox;
        private System.Windows.Forms.TextBox ResultBox;
        private System.Windows.Forms.RadioButton find_ID_Radio;
        private System.Windows.Forms.RadioButton find_age_Radio;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button Find_Record;
        private System.Windows.Forms.Label messageLabel;
        private System.Windows.Forms.Label connState;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button JerseyProfitButton;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button JerseyTaxButton;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button RedAnimals;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button DogRatioButton;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button MilkvsWoolButton;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button AveAgeButton;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button MonthlyTaxButton;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Button GetMilkButton;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Button TotalProfitButton;
    }
}

