﻿using System.Data.OleDb;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AppDev_FinalFarm
{
    class Commodies
    {
        // Instance Variables
        private double goatMilkPrice;
        private double cowMilkPrice;
        private double woolPrice;
        private double waterPrice;
        private double govTax;
        private double jerseyTax;
        private string com;
        private string strGoat = "Goat milk price";
        private string strSheep = "Sheep wool price";
        private string strWater = "Water price";
        private string strGovTax = "Government tax per kg";
        private string strJersey = "Jersy cow tax";
        private string strCow = "Cow milk price";

        // Constuctor
        public Commodies()
        {
            //GoatMilkPrice = 4.55;
            //CowMilkPrice = 3.4;
            //WoolPrice = 3.2;
            //WaterPrice = 1.4;
            //GovTax = 0.02;  // Per KG
            //JerseyTax = 0.01;
        }
        public Commodies(OleDbDataReader reader)
        {
            com = reader["Commodity"].ToString();
            //price = double.Parse(reader["Price"].ToString());

            if (com == strGoat)
            {
                GoatMilkPrice = double.Parse(reader["Price"].ToString());
            }
            else if (com == strSheep)
            {
                WoolPrice = double.Parse(reader["Price"].ToString());
            }
            else if (com == strWater)
            {
                WaterPrice = double.Parse(reader["Price"].ToString());
            }
            else if (com == strGovTax)
            {
                GovTax = double.Parse(reader["Price"].ToString());
            }
            else if (com == strJersey)
            {
                JerseyTax = double.Parse(reader["Price"].ToString());
            }
            else if (com == strCow)
            {
                CowMilkPrice = double.Parse(reader["Price"].ToString());
            }
            else
            {
                MessageBox.Show("Error in importing Commodities:\n" +
                    "Commodity: " + com +
                    "\nPrice: " + double.Parse(reader["Price"].ToString()));
            }

        }

        //Methods

        /// <summary>
        /// Gets formatted string of enitre object
        /// </summary>
        /// <returns>String</returns>
        public string Display()
        {
            string str = string.Format("{0} = {1}\n{2} = {3}\n{4} = {5}\n{6} = {7}\n{8} = {9}\n{10} = {11}", 
                strGoat, GoatMilkPrice.ToString(), 
                strCow, CowMilkPrice.ToString(), 
                strSheep, WoolPrice.ToString(), 
                strWater, WaterPrice.ToString(), 
                strGovTax, GovTax.ToString(), 
                strJersey, JerseyTax.ToString());
            return str;
        }

        // Properties
        public double GoatMilkPrice
        {
            get { return goatMilkPrice; }
            set { goatMilkPrice = value; }
        } // End of Property 
        public double CowMilkPrice
        {
            get { return cowMilkPrice; }
            set { cowMilkPrice = value; }
        } // End of Property 
        public double WoolPrice
        {
            get { return woolPrice; }
            set { woolPrice = value; }
        } // End of Property 
        public double WaterPrice
        {
            get { return waterPrice; }
            set { waterPrice = value; }
        } // End of Property 
        public double GovTax
        {
            get { return govTax; }
            set { govTax = value; }
        } // End of Property 
        public double JerseyTax
        {
            get { return jerseyTax; }
            set { jerseyTax = value; }
        } // End of Property 
    }
}
