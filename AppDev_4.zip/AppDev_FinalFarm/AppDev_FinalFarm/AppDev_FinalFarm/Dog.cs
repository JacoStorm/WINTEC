﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.OleDb;

namespace AppDev_FinalFarm
{
    class Dog : Animals
    {
        // Constructor 
        public Dog(OleDbDataReader reader)
            : base(reader, "DOG")
        {
        } // End of Constructor

        // Methods

        /// <summary>
        /// Returns total profit of farm
        /// </summary>
        /// <returns>Double</returns>
        public override double GetProfit()
        {
            double dailyWater = GetDailyWaterCost();
            double ex = dailyCost + dailyWater + GetTax();
            double sum = ex;
            return sum;
        }

        /// <summary>
        /// Returns total expense of animal
        /// </summary>
        /// <returns>double</returns>
        public override double GetExpense()
        {
            double dailyWater = GetDailyWaterCost();
            double ex = dailyCost + dailyWater + GetTax();
            return ex;
        }

        /// <summary>
        /// Returns daily water cost of related animal
        /// </summary>
        /// <returns>Double</returns>
        private double GetDailyWaterCost()
        {
            double ex = (Com.WaterPrice / 1000) * numWater;
            return ex;
        }

        /// <summary>
        /// Returns total tax of animal
        /// </summary>
        /// <returns>double</returns>
        public override double GetTax()
        {
            double tax = 0;
            return tax;
        }

        /// <summary>
        /// Returns formatted string of entire animal 
        /// </summary>
        /// <returns>string</returns>
        public override string getProp()
        {
            string str = string.Format("ID: {0}  {1}  |  Daily Water: {2}l   |   Cost: ${3} perDay   |   Weight: {4}kg   |   Age: {5}years old   |   Colour: {6}", ID.ToString(), Animal, NumWater.ToString(), DailyCost.ToString(), Weight.ToString(), Age.ToString(), Colour);
            return str;
        }

    }
}
