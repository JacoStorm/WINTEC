﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.OleDb;

namespace AppDev_FinalFarm
{
    class Reports
    {
        /// <summary>
        /// Calcuate total profit of farm
        /// </summary>
        /// <param name="dict">Dictionary Object of <Int, Class Animal></Int></param>
        /// <returns>double</returns>
        public static double CalProfit(Dictionary<int, Animals> dict)
        {
            double cur = 0.0;

            foreach (KeyValuePair<int, Animals> animal in dict)
            {
                cur += animal.Value.GetProfit();
            }

            return cur;
        }

        /// <summary>
        /// Calculats profit from all milk
        /// </summary>
        /// <param name="dict">Dictionary Object of <Int, Class Animal></Int></param>
        /// <returns>double</returns>
        public static double getAllMilk(Dictionary<int, Animals> dict)
        {
            double milk = 0;
            foreach (KeyValuePair<int, Animals> animal in dict)
            {
                milk += animal.Value.GetMilk();
            }
            return milk;
        }

        /// <summary>
        /// Calculates monthly tax
        /// </summary>
        /// <param name="dict">Dictionary Object of <Int, Class Animal></Int></param>
        /// <returns>double</returns>
        public static double MonthlyTax(Dictionary<int, Animals> dict)
        {
            double monthlyTX = 0;
            foreach (KeyValuePair<int, Animals> animal in dict)
            {
                monthlyTX += animal.Value.GetTax();
            }
            monthlyTX = monthlyTX / 12;
            return monthlyTX;
        }

        /// <summary>
        /// Calculates average ages of all animals on farm
        /// </summary>
        /// <param name="dict">Dictionary Object of <Int, Class Animal></Int></param>
        /// <returns>int</returns>
        public static int AveAge(Dictionary<int, Animals> dict)
        {
            int age = 0;
            int count = 0;
            foreach (KeyValuePair<int, Animals> animal in dict)
            {
                age += animal.Value.GetAge();
                count++;
            }
            int aveage = age / count;
            return aveage;
        }

        /// <summary>
        /// Calculates 
        /// </summary>
        /// <param name="dict">Dictionary Object of <Int, Class Animal></Int></param>
        /// <returns>double</returns>
        public static double MilkProfifts(Dictionary<int, Animals> dict)
        {
            double milk = 0;

            foreach (KeyValuePair<int, Animals> item in dict)
            {
                if (item.Value.Animal == "GOAT" || item.Value.Animal == "COW")
                {
                    milk = item.Value.GetProfit();
                }
            }
            return milk;
        }

        /// <summary>
        /// Calculated profits from wool
        /// </summary>
        /// <param name="dict">Dictionary Object of <Int, Class Animal></Int></param>
        /// <returns>double</returns>
        public static double WoolProfifts(Dictionary<int, Animals> dict)
        {
            double wool = 0;

            foreach (KeyValuePair<int, Animals> item in dict)
            {
                if (item.Value.Animal == "SHEEP")
                {
                    wool = item.Value.GetProfit();
                }
            }
            return wool;
        }

        /// <summary>
        /// Calculates total expenses of all dogs
        /// </summary>
        /// <param name="dict">Dictionary Object of <Int, Class Animal></Int></param>
        /// <returns>double</returns>
        public static double GetDogExp(Dictionary<int, Animals> dict)
        {
            double ex = 0;
            foreach (KeyValuePair<int, Animals> item in dict)
            {
                if (item.Value.Animal == "DOG")
                {
                    ex += item.Value.GetProfit();
                }
            }
            return ex;
        }

        /// <summary>
        /// Calculates total expenses of farm
        /// </summary>
        /// <param name="dict">Dictionary Object of <Int, Class Animal></Int></param>
        /// <returns>double</returns>
        public static double GetExpense(Dictionary<int, Animals> dict)
        {
            double ex = 0;
            foreach (KeyValuePair<int, Animals> item in dict)
            {
                
                ex += item.Value.GetExpense();
                
            }
            return ex;
        }

        /// <summary>
        /// Check and returns count of all animals with red fur
        /// </summary>
        /// <param name="dict">Dictionary Object of <Int, Class Animal></Int></param>
        /// <returns>int</returns>
        public static int GetRedLivestock(Dictionary<int, Animals> dict)
        {
            int count = 0;
            foreach (KeyValuePair<int, Animals> item in dict) if (item.Value.Colour == "red") count++;
            return count;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="dict">Dictionary Object of <Int, Class Animal></Int></param>
        /// <returns>int</returns>
        public static int Count(Dictionary<int, Animals> dict)
        {
            int count = 0;
            foreach (var item in dict)
            {
                count++;
            }
            return count;
        }

        /// <summary>
        /// Returns tax for all jersy cows
        /// </summary>
        /// <param name="dict">Dictionary Object of <Int, Class Animal></Int></param>
        /// <returns>double</returns>
        public static double GetJersyTax(Dictionary<int, Animals> dict)
        {
            double ex = 0;
            foreach (KeyValuePair<int, Animals> item in dict)
            {
                if (item.Value.IsJesrsy())
                {
                    ex += item.Value.GetJersyTax();
                }
            }
            return ex;
        }

        /// <summary>
        /// returns profits for all jersy cows
        /// </summary>
        /// <param name="dict">Dictionary Object of <Int, Class Animal></Int></param>
        /// <returns>double</returns>
        public static double GetJersyProfit(Dictionary<int, Animals> dict)
        {
            double cur = 0.0;
            foreach (KeyValuePair<int, Animals> animal in dict)
            {
                if (animal.Value.IsJesrsy())
                {
                    cur += animal.Value.GetProfit();
                }  
            }
            return cur;
        }

        /// <summary>
        /// Returns age range. 
        /// </summary>
        /// <param name="dict">Dictionary Object of <Int, Class Animal></Int></param>
        /// <param name="age">Age of animal</param>
        /// <returns>int</returns>
        public static int GetAgeRange(Dictionary<int, Animals> dict, int age)
        {
            int count = 0;
            foreach (KeyValuePair<int,Animals> item in dict)
            {
                if (item.Value.Age > age)
                {
                    count++;
                }
            }
            return count;
        }
    }
}