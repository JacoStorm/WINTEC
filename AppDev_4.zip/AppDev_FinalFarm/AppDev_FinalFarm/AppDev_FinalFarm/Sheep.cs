﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.OleDb;

namespace AppDev_FinalFarm
{
    class Sheep : Animals
    {
        // Instance Variables
        private double numWool;

        // Constructor 
        public Sheep(OleDbDataReader reader)
            : base(reader, "SHEEP")
        {
            NumWool = double.Parse(reader["Amount of wool"].ToString());
        } // End of Constructor

        // Methods

        /// <summary>
        /// Returns total profit of farm
        /// </summary>
        /// <returns>Double</returns>
        public override double GetProfit()
        {
            double income = GetIncome();
            // Calculates the expenses for each animal
            double dailyWater = GetDailyWaterCost();
            double ex = dailyCost + dailyWater + GetTax();
            double sum = income - ex;
            return sum;
        }

        /// <summary>
        /// Returns daily water cost of related animal
        /// </summary>
        /// <returns>Double</returns>
        private double GetDailyWaterCost()
        {
            double ex = (Com.WaterPrice / 1000) * numWater;
            return ex;
        }

        /// <summary>
        /// Gets the income produced by the animal
        /// </summary>
        /// <returns>double</returns>
        private double GetIncome()
        {
            double income = NumWool * Com.WoolPrice;
            return income;
        }

        /// <summary>
        /// Returns total expense of animal
        /// </summary>
        /// <returns>double</returns>
        public override double GetExpense()
        {
            double dailyWater = GetDailyWaterCost();
            double ex = dailyCost + dailyWater + GetTax();
            return ex;
        }

        /// <summary>
        /// Returns total tax of animal
        /// </summary>
        /// <returns>double</returns>
        public override double GetTax()
        {
            double sum = Weight * Com.GovTax;
            return sum;
        }

        /// <summary>
        /// Returns formatted string of entire animal 
        /// </summary>
        /// <returns>string</returns>
        public override string getProp()
        {
            string str = string.Format("ID: {0}  {1}  |  Daily Water: {2}l   |   Cost: ${3} perDay   |   Weight: {4}kg   |   Age: {5}years old   |   Colour: {6}   |   Wool: {7}kg/perday", ID.ToString(), Animal, NumWater.ToString(), DailyCost.ToString(), Weight.ToString(), Age.ToString(), Colour, NumWool);
            return str;
        }

        // Properties
        public double NumWool
        {
            get { return numWool; }
            set { numWool = value; }
        } // End of Property 
    }
}
