﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.OleDb;

namespace AppDev_FinalFarm
{
    class Animals
    {
        // Instance variables
        protected int id;
        protected string animal;
        protected double numWater;
        protected double dailyCost;
        protected double weight;
        protected int age;
        protected string colour;
        protected double profit;
        protected Commodies Com = new Commodies();


        // Constructor

        /// <summary>
        /// Constructor to create new LiveStock calss
        /// </summary>
        /// <param name="reader"></param>
        /// <param name="animalType">String for the type of animal to be added to array</param>
        public Animals(OleDbDataReader reader, string animalType)
        {
            // int ID, double Amount of Water, double Daily Cost, double Weight, int Ages, string Colour, doulbe, Extra data for per animal
            ID = int.Parse(reader["ID"].ToString());
            Animal = animalType;
            NumWater = double.Parse(reader["Amount of water"].ToString());
            DailyCost = double.Parse(reader["daily cost"].ToString());
            Weight = double.Parse(reader["weight"].ToString());
            Age = int.Parse(reader["age"].ToString());
            Colour = reader["color"].ToString();
        } // End of Constructor

        // Methods

        /// <summary>
        /// Returns total profit of farm
        /// </summary>
        /// <returns>Double</returns>
        public virtual double GetProfit()
        {
            profit = 0;

            // Calculates the daily water costs for each animal
            double dailyWater = Com.WaterPrice / 1000 * numWater;

            // Calculates the expenses for each animal
            double ex = dailyCost + dailyWater + GetTax();
            double sum = profit - ex;
            return sum;
        }

        /// <summary>
        /// Returns total tax of animal
        /// </summary>
        /// <returns>double</returns>
        public virtual double GetTax()
        {
            double sum = Weight * Com.GovTax;
            return sum;
        }

        /// <summary>
        /// Returns formatted string of entire animal 
        /// </summary>
        /// <returns>string</returns>
        public virtual string getProp()
        {
            string str = string.Format("ID:\t{0},\t{1},\t Daily Water: {2}l,\tCost: ${3} perDay,\tWeight: {4}kg,\tAge: {5}years old, \tColour: {6}", 
                ID.ToString(), Animal, NumWater.ToString(), DailyCost.ToString(), Weight.ToString(),Age.ToString(), Colour);
            return str;
        }

        /// <summary>
        /// Returns total amount of milk produced
        /// </summary>
        /// <returns>double</returns>
        public virtual double GetMilk()
        {
            double numMilk = 0;
            return numMilk;
        }

        /// <summary>
        /// returns age of animal
        /// </summary>
        /// <returns>int</returns>
        public int GetAge()
        {
            int age = 0;
            if (getAnimalType() != "dog")
            {
                age = Age;
            }
            return age;
        }

        /// <summary>
        /// Returns string type of animal
        /// </summary>
        /// <returns>string</returns>
        public string getAnimalType()
        {
            string type = animal;
            return type;
        }

        /// <summary>
        /// Returns total expense of animal
        /// </summary>
        /// <returns>double</returns>
        public virtual double GetExpense()
        {
            double dailyWater = Com.WaterPrice / 1000 * numWater;
            double ex = dailyCost + dailyWater + GetTax();
            double sum = ex;
            return sum;
        }

        /// <summary>
        /// Returns bool if object is of Jersy type
        /// </summary>
        /// <returns>bool</returns>
        public virtual bool IsJesrsy()
        {
            bool flag = false;
            return flag;
        }

        /// <summary>
        /// Check and returns type Jersy tax
        /// </summary>
        /// <returns>double</returns>
        public virtual double GetJersyTax()
        {
            double sum = 0;
            return sum;
        }

        // Properties
        public int ID
        {
            get { return id; }
            set { id = value; }
        } // End of Property 
        public string Animal
        {
            get { return animal; }
            set { animal = value; }
        } // End of Property 
        public double NumWater
        {
            get { return numWater; }
            set { numWater = value; }
        } // End of Property 
        public double DailyCost
        {
            get { return dailyCost; }
            set { dailyCost = value; }
        } // End of Property 
        public double Weight
        {
            get { return weight; }
            set { weight = value; }
        } // End of Property 
        public int Age
        {
            get { return age; }
            set { age = value; }
        } // End of Property 
        public string Colour
        {
            get { return colour; }
            set { colour = value; }
        } // End of Property 
        public double Profit { get; set; } // End of Property 
    }
}
