'''
Program 3: Draw Snowman

Author: Jaco Storm 15435194

Plegde of Honour: I Plegde by honour that this program is solely my own work.

Description: This program draws a full snowman

'''

from turtle import*

def move_to(x,y):
    #Move to a location without drawing a line
    pu()
    goto(x,y)
    pd()

def draw_line(x1, y1, x2, y2):
    # Start line from (x1, y1) and go to (x2, y2)
    move_to(x1, y1)
    goto(x2, y2)

def draw_circle(x, y, radius, colour):
   # (x,y) is the starting point of the circle (at the bottum)
   # radius is the circle radius, colour is the fill colour
    move_to(x,y)
    
    ''' Added code to draw in colour '''
    # Draw cicle with parameter specifications
    setheading(0)
    begin_fill()
    fillcolor(colour)
    circle(radius)
    end_fill()


def draw_triangle(x, y, size, colour):
    # (x,y) is the starting point of the triangle
    # size is the lenght of the triangle, colour is the fill colour
    move_to(x,y)

    ''' Added code to draw triangle in colour '''

    # Draw triangle with parameter specifications
    begin_fill()
    fillcolor(colour)
    for i in range(3):  #Loop with 3 seperate lines to draw triangle
        fd(size)
        rt(120)
    end_fill()
    
    
def draw_head():
    # Draw head with hat, eye and nose

    ''' Added code w/h functions to draw head, hat, eyes  '''
    
    draw_hat()
    draw_face()
    draw_eyes()
    draw_triangle(-10,25,20,'orange')

def draw_eyes():
    ''' draws two small black filled circles @ locations -15,40 and 15,40 '''

    # Set up variables
    x,y,r = -15,40,5
    crl = 'black'

    # Draw first eye
    move_to(x,y)
    begin_fill()
    fillcolor(crl)
    circle(r)
    end_fill()

    # Set up new variables for second eye
    x,y,r = 15,40,5
    crl = 'black'

    # Draw second eye
    move_to(x,y)
    begin_fill()
    fillcolor(crl)
    circle(r)
    end_fill()
    
def draw_face():
    ''' draws a circle @ 0,-20 with a radius of 50 '''

    # Set up variables
    x,y,r = 0,-20,50
    crl = 'linen'

    # Draw face 
    move_to(x,y)
    begin_fill()
    fillcolor(crl)
    circle(r)
    end_fill()

def draw_hat():
    ''' Draws circle @ starting posistion 0,30 with radius of 40 and filled colour of red '''

    # Set up variables
    x,y,r = 0,30,40
    crl = 'red'

    # Draw hat
    move_to(x,y)
    begin_fill()
    fillcolor(crl)
    circle(r)
    end_fill()        

def draw_lower_body():
    ''' Draws arms, and two circles for the snowmans body '''
    

    # Set up variables
    crl = 'linen'
    ''' Added code with functions calls to draw tummy, arms, thigh '''

    # Draw lowerbody
    draw_arms()
    draw_circle(0,-150,75,crl)
    draw_circle(0,-280,100,crl)
    
    
def draw_arms():
    # Set up variables
    crl = 'black'

    # Draw arms with triangles for hands
    draw_line(-150,-40,150,-40)
    draw_triangle(-150,-40,60,crl)
    draw_triangle(90,-40,60,crl)



def main():
    speed(0)
    pensize(3)
    pencolor('black')

    draw_head()
    draw_lower_body()

    hideturtle()
    exitonclick()

main()
