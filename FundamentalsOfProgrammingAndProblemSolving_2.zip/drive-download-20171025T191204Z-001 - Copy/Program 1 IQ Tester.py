'''
Program 1: IQ Tester

Author: Jaco Storm 15435194

Plegde of Honour: I Plegde by honour that this program is solely my own work.

Description: Determines the result of a IQ using a predefined scale. User enters his score and
the program will then display the result according to the predefined scale.

'''

# Get input
score = int(input('Enter your IQ score as a whole positive number: '))

# Check data and compare to defenied groups

if score < 70:
    print('Your score is ' + str(score) + " and its classed as "+ "Definite feeble-mindedness")  
elif score <= 79 and score >= 70:
    print('Your score is ' + str(score) + " and its classed as "+ 'Boderline deficienct') 
elif score <= 89 and score >= 80:
    print('Your score is ' + str(score) + " and its classed as "+ 'Dullness') 
elif score <= 109 and score >= 90:
    print('Your score is ' + str(score) + " and its classed as "+ 'Normal or average intelligence')  
elif score <= 119 and score >= 110:
    print('Your score is ' + str(score) + " and its classed as "+ 'Superior intelligence')  
elif score <= 140 and score >= 120:
    print('Your score is ' + str(score) + " and its classed as "+ 'Very superior intelligence')    
else:
    print('Your score is ' + str(score) + " and its classed as "+ 'Genius or near genius')



print('Done') # Indicator for End of Program

