'''
Program 3: 

Author: Jaco Storm 15435194

Plegde of Honour: I Plegde by honour that this program is solely my own work.

Description: This program organise student records and display them in a reader friendly manor.

'''


''' Templated added from Practical 2 Instruction PDF '''
from datetime import datetime

def print_course_list(records):
    ''' Print all records of the listed course in a user friendly format on screen '''
    # Create template
    temp = '{0:17}{1:25}{2:19}{3:5}'

    # Printing Titled and Headers
    title = ['Course ID','Course Name','Num Students','Num Passed']
    row = temp.format(title[0],title[1],title[2],title[3])
    print(row)  # Display heading
    print('-'*71) # Display line

    # Print each row with formatted template
    for count in records:
        row = temp.format(count[0], count[1], count[2], count[3])
        print(row)  # Print each row 1 at a time

    
def overall_summary(records):
    '''
        Calculate the overall total number of student
        total number of student that passed and the overall pass rate
    '''

    ''' Added code '''
    # Calculate Total Students:
    studentSum = 0 # Empty counter
    for elem in records:    # Cycle through each element
        studentSum += int(elem[2]) # Add each element value to totalStudent
    
    # Calculate Total Pass:
    passNum = 0     # Empty counter
    for elem in records: # Cycle through each element
        passNum += int(elem[3])  # Add each element value to StudentSum
        
    # Average Pass Rate:
    passRate = passNum/studentSum  # Calculate Average Pass Rate
    fmt = '{0:5.2%}'
    AveResult = fmt.format(passRate) # Display results
        
    # Print data
    print()
    print('Total Students: ', studentSum)
    print('Total Passed: ', passNum)
    print('Average Pass Rate: ', AveResult)
    print()

def course_summary(records):
    ''' search people for the name, calculate the pass rate for the course and show messafe if course doesnt exist '''

    ''' Added code '''

    # Get data
    courseID = input('Enter Course ID: ')  # Target
    # Search records for target
    for rec in records:
        if courseID == rec[0]: # Target match
            print('Course name:',rec[1])
            print('Total students in',rec[0],':',rec[2])
            print('Students Passing in',rec[0],':',rec[3])
            break
        # Error input Checking
        if courseID != rec[0]:
            print('No match found')
            break 
    
    # Check Matrix for courseName
    print('\nEnd of Report. \n')

def getdata():
    '''
        Prepare the course_list
        (course_id, course_name, number of students, number of students that passed)
    '''

    course_list = []
    course_list.append(['comp001','Fundamentals','96','84'])
    course_list.append(['comp002','database Principles','104','92'])
    course_list.append(['comp003','Networking','120','106'])
    course_list.append(['como004','Website Development','110','102'])
    return course_list

def main():
    data = getdata()
    print_course_list(data)
    overall_summary(data)
    course_summary(data)

main()









    
    
