'''
Program 5: 

Author: Jaco Storm 15435194

Plegde of Honour: I Plegde by honour that this program is solely my own work.

Description:

'''

from datetime import datetime

def readdata(fname):
    # Read file contect, compose a list, return the list
    print('*'*5,'Reading Records From File',fname,'*'*5)
    
    data = []

    ''' Added code '''
    date_fm = '%d-%m-%Y'
    count = 0
    with open(fname,'r') as readfile:
        for line in readfile:
            a_line = line.split(',')
            date_str = a_line[0]
            date_obj = datetime.strptime(date_str,date_fm)
            rec = [date_obj,a_line[1],float(a_line[2])]
            data.append(rec)
    
    print('Done.\n\n')
    return data

def print_all_records(records):
    # Print all records

    print('*'*18,'Printing All Records','*'*18)
    print()
    temp = '{0:<20}{1:<25}{2:<15}'
    date_fm = '%d-%m-%Y'
    for count in records:
        row = temp.format(datetime.strftime(count[0],date_fm),count[1],float(count[2]))
        print(row)

    print()
    print()

def calc_statictics(records):
    # Calculate the number, total, average of purchase
    print('*'*10,'Calculating Purchase Statistics','*'*15)

    ''' Added Code '''
    # Calculate number of purshases
    numbought = len(records)

    # Calculate total amount purchased
    sumBuy = 0
    for rec in records:
        sumBuy += rec[2]

    # Calculate average Purshase
    ave = sumBuy/numbought

    # Display statictical information
    print('Number of purchases: $',numbought)
    print('Total purchase: $',sumBuy)
    print('Average purchase amount: $',ave)
    print('Done.\n\n')

def writedata(filename, data):
    # write data (a list) to filename
    print('*'*17,'Saving Records to File','*'*17)
    
    ''' Added Code '''
    # Write each Matrix into backup.txt
    with open(filename,'w') as writefile:
        for rec in data:  # Write each line at a time
            
            date = rec[0].strftime('%d-%m-%Y')
            new_rec = [date, rec[1], str(rec[2])] # Create new records to be written
            line = ','.join(new_rec) # Join as single line
            writefile.write(line + '\n')   # Write to file

    print('Done.\n\n')

def main():

    records = readdata('shopping_details.txt')
    print_all_records(records)
    calc_statictics(records)
    writedata('NewBackup.txt', records)

main()





    
