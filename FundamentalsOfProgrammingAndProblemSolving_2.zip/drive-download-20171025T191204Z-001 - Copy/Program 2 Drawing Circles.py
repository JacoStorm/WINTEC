'''
Program 2: Circle Drawing tool

Author: Jaco Storm 15435194

Plegde of Honour: I Plegde by honour that this program is solely my own work.

Description: User to input a number (2 - 6) and prgram will draw that number of circles

'''
# Import drawing tools and variables
from turtle import*
speed(40) # Speed controller
r = 30  # Radius of circles
x , y = -200, -200 # Start coord


num_circles = int(input('Enter the number of circles (2 - 6 incl): ')) # Get input



while num_circles < 2 or num_circles > 6: # User input checking
    # Error messsage
    print()
    print("Incorrect number of circles. Please read instructions carefull.")
    # Re-entry message
    num_circles = int(input('Enter the number of circles (2 - 6 incl): '))


def move_to(x , y):
    '''
    Function to help move pen to new location without drawing.
    x and y represent x and y coordinate respectively
    '''
    pu() 
    goto(x,y) 
    pd() 

countWid = 0 # Empty counter for Width
countHigh = 0 # Empty counter for Height

while countHigh < num_circles: # Loop to count vertical climb
    countWid = 0 # reset counter for Width
    
    while countWid < num_circles:   # Loop to count Horizontal Climb
        move_to(x,y)    # Move to start location
        circle(r)    # Draw a single circle
        x += r * 2    # Set up new location 
        countWid += 1   # Counter number of circles being drawn
    x = -200    # reset coord 
    y += r*2    # reset coord 
    countHigh += 1  # Count number of circles being draw
hideturtle()
exitonclick()
