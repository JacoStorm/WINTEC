package com.example.kiteappv2;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class Pine extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pine);
        Beach_Fragment beach = (Beach_Fragment) getSupportFragmentManager().findFragmentById(R.id.fragment);

        beach.setPineInfo();
    }
}
