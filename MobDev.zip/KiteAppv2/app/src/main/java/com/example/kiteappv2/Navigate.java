package com.example.kiteappv2;

import androidx.fragment.app.FragmentActivity;
import android.nfc.Tag;
import android.util.Log;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.view.View;
import android.os.Bundle;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.LatLngBounds;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.model.Polyline;
import com.google.android.gms.maps.model.PolylineOptions;
import android.view.MotionEvent;
import android.view.GestureDetector;


public  class Navigate extends FragmentActivity implements
        OnMapReadyCallback, GoogleMap.OnInfoWindowClickListener, GestureDetector.OnGestureListener,
        GestureDetector.OnDoubleTapListener{

    private static final String TAG = "Messages";
    private GoogleMap mMap;
    private LatLngBounds mMapBoundry;
    private GestureDetector gestureDetector;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_navigate);
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);
        Log.i(TAG,"onCreate");
    }

    /**
     * Add new beaches as activities
     * Add Carsoul
     * Change Switch colours
     */
    @Override
    public void onMapReady(GoogleMap googleMap) {
        Log.i(TAG,"onMapReady");
        mMap = googleMap;
        Polyline polygon;

        setHomeCam();
        loadBeaches();

        mMap.setOnInfoWindowClickListener(this);
        this.gestureDetector = new GestureDetector(this, this);
        gestureDetector.setOnDoubleTapListener(this);

    }

    private void loadBeaches(){
        LatLng raglan = new LatLng(-37.803523, 174.843948);
        LatLng pineHarbour = new LatLng(-36.891690, 174.988694);
        LatLng easternBeach = new LatLng(-36.870110, 174.911753);
        LatLng takapuna = new LatLng(-36.785295, 174.775341);

        addMarkers(raglan, "Raglan");
        addMarkers(pineHarbour, "Pine Harbour");
        addMarkers(easternBeach, "Eastern Beach");
        addMarkers(takapuna, "Takapuna");

        Polyline raglanBoundry = mMap.addPolyline(new PolylineOptions().clickable(true).add(
                new LatLng(-37.803918,174.843990),
                new LatLng(-37.803856,174.845081),
                new LatLng(-37.804203,174.846617),
                new LatLng(-37.798257,174.849046),
                new LatLng(-37.798003,174.846675),
                new LatLng(-37.797443,174.839525),
                new LatLng(-37.797375,174.836704),
                new LatLng(-37.807053,174.835545),
                new LatLng(-37.803918,174.843990)
        ));

        Polyline easternBeachBoundry = mMap.addPolyline(new PolylineOptions().clickable(true).add(
                new LatLng(-36.867821, 174.911084),
                new LatLng(-36.871332, 174.913124),
                new LatLng(-36.875028, 174.916363),
                new LatLng(-36.877741, 174.919473),
                new LatLng(-36.876395, 174.922920),
                new LatLng(-36.873548, 174.923111),
                new LatLng(-36.866151, 174.914524),
                new LatLng(-36.867821, 174.911084)
        ));

        Polyline takapunaBoundry = mMap.addPolyline(new PolylineOptions().clickable(true).add(
                new LatLng(-36.784959, 174.775827),
                new LatLng(-36.786344, 174.775703),
                new LatLng(-36.788873, 174.777297),
                new LatLng(-36.792024, 174.780765),
                new LatLng(-36.795306, 174.785601),
                new LatLng(-36.793559, 174.787217),
                new LatLng(-36.784570, 174.778727),
                new LatLng(-36.784975, 174.777345),
                new LatLng(-36.784959, 174.775827)
        ));

        Polyline pineHarbourBoundry = mMap.addPolyline(new PolylineOptions().clickable(true).add(
                new LatLng(-36.891869, 174.988205),
                new LatLng(-36.896775, 174.987357),
                new LatLng(-36.898461, 174.985540),
                new LatLng(-36.902274, 174.980798),
                new LatLng(-36.902646, 174.969468),
                new LatLng(-36.908799, 174.965473),
                new LatLng(-36.906689, 174.957536),
                new LatLng(-36.899547, 174.961228),
                new LatLng(-36.893180, 174.975430),
                new LatLng(-36.879813, 174.978195),
                new LatLng(-36.879144, 174.980103),
                new LatLng(-36.878526, 174.980638),
                new LatLng(-36.877468, 174.980854),
                new LatLng(-36.879588, 174.982701),
                new LatLng(-36.881231, 174.981697),
                new LatLng(-36.882224, 174.981432),
                new LatLng(-36.890819, 174.984889),
                new LatLng(-36.891539, 174.986647),
                new LatLng(-36.891719, 174.987622),
                new LatLng(-36.891869, 174.988205)
        ));
    }

    private void addMarkers(LatLng loc, String name){
        mMap.addMarker(new MarkerOptions().position(loc).title(name));
    }

    private void setBeachCam(LatLng loc){
        // Set boundries
        double buttonBound = loc.latitude - .5;
        double leftBound = loc.longitude - .5;
        double topBound = loc.latitude + .5;
        double rightBound = loc.longitude + .5;

        // Apply boundry
        mMapBoundry = new LatLngBounds(
                new LatLng(buttonBound,leftBound),
                new LatLng(topBound,rightBound)
        );

        // Move camera to boundry
        mMap.moveCamera(CameraUpdateFactory.newLatLngBounds(mMapBoundry,0));
    }

    private void setHomeCam(){
        Log.i(TAG,"setCam");
        LatLng nz = new LatLng(-41.785002, 174.018419);
        // Set boundries
        double buttonBound = nz.latitude - 5;
        double leftBound = nz.longitude - 5;
        double topBound = nz.latitude + 5;
        double rightBound = nz.longitude + 5;

        // Apply boundry
        mMapBoundry = new LatLngBounds(
                new LatLng(buttonBound,leftBound),
                new LatLng(topBound,rightBound)
        );

        // Move camera to boundry
        mMap.moveCamera(CameraUpdateFactory.newLatLngBounds(mMapBoundry,0));
    }

    @Override
    public boolean onSingleTapConfirmed(MotionEvent e) {
        return false;
    }

    @Override
    public boolean onDoubleTap(MotionEvent e) {
        return false;
    }

    @Override
    public boolean onDoubleTapEvent(MotionEvent e) {
        return false;
    }

    @Override
    public boolean onDown(MotionEvent e) {
        return false;
    }

    @Override
    public void onShowPress(MotionEvent e) {

    }

    @Override
    public boolean onSingleTapUp(MotionEvent e) {
        return false;
    }

    @Override
    public boolean onScroll(MotionEvent e1, MotionEvent e2, float distanceX, float distanceY) {
        return false;
    }

    @Override
    public void onLongPress(MotionEvent e) {

    }

    @Override
    public boolean onFling(MotionEvent e1, MotionEvent e2, float velocityX, float velocityY) {
        return false;
    }

    public void onInfoWindowClick(final Marker marker) {
        // build the dialoaf
        Log.i(TAG,"onInfoWindowClick");
        marker.setSnippet("Check out the beach?");
        final AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setMessage(marker.getSnippet());
        builder.setCancelable(true);
        builder.setPositiveButton("yes", new DialogInterface.OnClickListener() {
            public void onClick(@SuppressWarnings("unused") final DialogInterface dialog, @SuppressWarnings("unused") final int id) {
                Log.i(TAG,"onClick");
                onClickToBeach(marker);
                dialog.dismiss();
            }
        }).setNegativeButton("No", new DialogInterface.OnClickListener() {
            public void onClick(final DialogInterface dialog, @SuppressWarnings("unused") final int id) {
                dialog.cancel();
            }
        }).show();
    }

    @Override
    public void onPointerCaptureChanged(boolean hasCapture) {

    }

    public void onClickToBeach(Marker marker){
        Log.i(TAG,"onClickToBeach");
        if (marker.getPosition().latitude == -37.803523){
            Intent i = new Intent(this, BeachView.class);
            startActivity(i);
        }
        // Pine
        else if (marker.getPosition().latitude == -36.891690){
            Intent i = new Intent(this,Pine.class);
            startActivity(i);
        }
        // Estern
        else if (marker.getPosition().latitude == 0){
            Intent i = new Intent(this,Pine.class);
        }
        // Takapuna
        else if (marker.getPosition().latitude == 1){
            Intent i = new Intent(this,Pine.class);
        }
    }


}
