package com.example.kiteappv2;

import android.nfc.Tag;
import android.util.Log;
import android.os.Bundle;
import android.support.v4.app.*;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Switch;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import com.google.android.gms.maps.model.LatLng;

public class Beach_Fragment extends Fragment {

    private static final String TAG = "Messages";
    // References
    private static Switch waveIn, flatIn, learnIn, toiletIn, showerIn, carParkIn, safeLaunchIn;
    private static Switch tideIn, rockIn, ripIn, kidFriendlyIn,boatIn, dogsAllowedIn;
    private static TextView beachName, region;
    private static ImageView beachPic;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.beach_info_fragment, container,false);
        Log.i(TAG,"onCreate_Frag");

        beachPic = (ImageView) view.findViewById(R.id.beachPic);
        beachName = (TextView) view.findViewById(R.id.beacNameText);
        region = (TextView) view.findViewById(R.id.regionText);
        waveIn = (Switch) view.findViewById(R.id.waveIndicator);
        flatIn = (Switch) view.findViewById(R.id.flatIndicator);
        learnIn = (Switch) view.findViewById(R.id.learnerIndicator);
        toiletIn = (Switch) view.findViewById(R.id.toiletsIndicator);
        showerIn = (Switch) view.findViewById(R.id.showerIndicator);
        carParkIn = (Switch) view.findViewById(R.id.parkingIndicator);
        safeLaunchIn = (Switch) view.findViewById(R.id.launchIndicator);
        tideIn = (Switch) view.findViewById(R.id.tideIndicator);
        rockIn = (Switch) view.findViewById(R.id.rockIndicator);
        ripIn = (Switch) view.findViewById(R.id.ripIndicator);
        kidFriendlyIn = (Switch) view.findViewById(R.id.kidIndicator);
        boatIn = (Switch) view.findViewById(R.id.boatIndicator);
        dogsAllowedIn = (Switch) view.findViewById(R.id.dogIndicator);
        return view;
    }

    public void setRaglanInfo() {
        Log.i(TAG,"setBeach called_Frag");
        resetBeach();
        raglan();
    }

    public void resetBeach(){

        beachName.setText("setBeachName");
        region.setText("setRegionName");
        waveIn.setChecked(false);
        flatIn.setChecked(false);
        learnIn.setChecked(false);
        toiletIn.setChecked(false);
        showerIn.setChecked(false);
        carParkIn.setChecked(false);
        safeLaunchIn.setChecked(false);
        tideIn.setChecked(false);
        rockIn.setChecked(false);
        ripIn.setChecked(false);
        kidFriendlyIn.setChecked(false);
        boatIn.setChecked(false);
        dogsAllowedIn.setChecked(false);

        Log.i(TAG,"resetBeach called_Frag");
    }

    public void raglan(){
        beachPic.setImageResource(R.drawable.download);
        beachName.setText("Raglan");
        region.setText("Waikato");
        waveIn.setChecked(true);
        flatIn.setChecked(true);
        toiletIn.setChecked(true);
        showerIn.setChecked(true);
        carParkIn.setChecked(true);
        safeLaunchIn.setChecked(true);
        tideIn.setChecked(true);
        kidFriendlyIn.setChecked(true);
        dogsAllowedIn.setChecked(true);
        Log.i(TAG,"raglan called_Frag");
    }

    public void setPineInfo(){
        resetBeach();
        pine();
    }

    public void pine(){

        beachPic.setImageResource(R.drawable.pine);
        beachName.setText("Pine Harbour");
        region.setText("Auckland");
        flatIn.setChecked(true);
        learnIn.setChecked(true);
        toiletIn.setChecked(true);
        showerIn.setChecked(true);
        carParkIn.setChecked(true);
        tideIn.setChecked(true);
        rockIn.setChecked(true);
        boatIn.setChecked(true);
    }

    public void taka(){
        beachPic.setImageResource(R.drawable.taka);
        beachName.setText("Takapuna");
        region.setText("Auckland");
        waveIn.setChecked(true);
        toiletIn.setChecked(true);
        showerIn.setChecked(true);
        carParkIn.setChecked(true);
        rockIn.setChecked(true);
        ripIn.setChecked(true);
        kidFriendlyIn.setChecked(true);
        boatIn.setChecked(true);
        dogsAllowedIn.setChecked(true);
    }
    public void setTakaInfo(){
        resetBeach();
        taka();
    }

    public void eastern(){
        beachPic.setImageResource(R.drawable.east);
        beachName.setText("Eastern");
        region.setText("Auckland");
        flatIn.setChecked(true);
        learnIn.setChecked(true);
        toiletIn.setChecked(true);
        showerIn.setChecked(true);
        carParkIn.setChecked(true);
        safeLaunchIn.setChecked(true);
        tideIn.setChecked(true);
        rockIn.setChecked(true);
        kidFriendlyIn.setChecked(true);

    }

    public void setEastInfo(){
        resetBeach();
        eastern();
    }

}
