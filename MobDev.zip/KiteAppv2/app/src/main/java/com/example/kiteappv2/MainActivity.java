package com.example.kiteappv2;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.content.Intent;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;

public class MainActivity extends AppCompatActivity {

    private static ImageView logoPic;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        logoPic = (ImageView) findViewById(R.id.splashImageView);
    }

    public void onClick(View view){
        Intent i = new Intent(this, Navigate.class);
        startActivity(i);
    }
}
