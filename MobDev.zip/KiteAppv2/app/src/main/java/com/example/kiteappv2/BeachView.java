package com.example.kiteappv2;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.os.Message;

public class BeachView extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_beach_view);
        Beach_Fragment beach = (Beach_Fragment) getSupportFragmentManager().findFragmentById(R.id.fragment);

        beach.setRaglanInfo();
    }
}
