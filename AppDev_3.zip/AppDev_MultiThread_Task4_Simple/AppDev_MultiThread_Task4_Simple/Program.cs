﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;

namespace AppDev_MultiThread_Task4_Simple
{
    /*
     
        Task: Consider a file that contains 100,000 integer. Develop an application that reads the text into an
        array of integers. Then, the application creates two threads that concurrently find the maximum of
        each half. Then calculate the maximum between them.
    */
    class Program
    {
        private static Object ThisLock = new Object();
        protected static int[] data;
        protected static int UpperSum;
        protected static int LowerSum;
        protected static int DataSum;

        static void Main(string[] args)
        {
            data = GenArray();
            Thread currentThread = Thread.CurrentThread;
            Thread thread1 = new Thread(new ThreadStart(GetUpperSum));
            Thread thread2 = new Thread(new ThreadStart(GetLowerSum));
            thread1.Start();

            while (thread1.IsAlive)  { Thread.Sleep(5); }

            thread2.Start();

            while (thread2.IsAlive) {Thread.Sleep(5); }

            DataSum = CalSum(LowerSum, UpperSum);

            Console.WriteLine("Lower total: " + LowerSum.ToString()
                            + "\nUpper total: " + UpperSum.ToString()
                            + "\nTotal of array: " + DataSum.ToString());
            Console.ReadKey();
        }

        private static int CalSum(int lower, int upper)
        {
            int sum = 0;
            sum = lower + upper;
            return sum;
        }

        private static void GetLowerSum()
        {
            Console.WriteLine("------       Executing Lower       ------\n");
            int sum = 0;
            for (int i = 0; i < data.Length / 2; i++) lock (ThisLock)
                {
                    Console.WriteLine("LowerTread : " + i + " + " + sum.ToString());
                    sum += i;
                }
            Console.WriteLine("------       Executed Lower        ------\n");
            LowerSum = sum;
        }

        private static void GetUpperSum()
        {
            Console.WriteLine("------       Executing Upper       ------\n");
            int sum = 0;
            for (int i = data.Length; i >= data.Length / 2; i--)
            {
                Console.WriteLine("UpperTread : " + i + " + " + sum.ToString());
                sum += i;
            }
            Console.WriteLine("------       Executed Upper        ------\n");
            UpperSum = sum;
        }

        private static int[] GenArray()
        {
            Console.WriteLine("------    Generating data          ------\n");
            int[] array = new int[100];
            Random random = new Random();
            for (int i = 0; i < array.Length; i++) { array[i] = random.Next(1, 1000); Console.WriteLine(i + " : " + array[i]); }
            Console.WriteLine("\n------ Data Generating Successfull ------\n");
            return array;
        }
    }
}
