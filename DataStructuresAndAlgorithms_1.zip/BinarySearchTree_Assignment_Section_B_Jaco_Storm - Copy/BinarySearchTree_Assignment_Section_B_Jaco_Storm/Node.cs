﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BinarySearchTree_Assignment_Section_B_Jaco_Storm
{
    class Node
    {
        // INSTANCE
        public int value;
        public Node left;
        public Node right;

        // CONSTRUCTOR
        public Node(int value)
        {
            this.value = value;
            left = null;
            right = null;
        }
    }
}
