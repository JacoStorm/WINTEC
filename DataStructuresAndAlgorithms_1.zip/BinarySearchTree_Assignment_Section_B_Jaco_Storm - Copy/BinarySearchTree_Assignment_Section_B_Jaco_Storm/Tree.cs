﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace BinarySearchTree_Assignment_Section_B_Jaco_Storm
{
    class Tree
    {
        // INSTANCE

        // starting point
        Node root;

        // CONSTRUCTOR

        /// <summary>
        /// Creating empty tree with no root
        /// </summary>
        public Tree()
        {
            root = null;
        }

        /// <summary>
        /// Creating empty tree with a root
        /// </summary>
        /// <param name="rootValue">Int value to be assigned to root</param>
        public Tree(int rootValue)
        {
            // Creating new Node with rootValue
            root = new Node(rootValue);
        }

        // METHODS
        public void Insert(int value)
        {
            //if there's nothing in the list, add to root
            if (root == null)
            {
                root = new Node(value);
            }
            else
            {
                //add to a leaf/child/end node
                Node current = root;
                Node parent = root;
                bool left = true;
                while (current != null)
                {
                    // System.Console.WriteLine(current.value);
                    //set parent
                    parent = current;
                    //traverse the tree (value < current.value)
                    if (current.value > value)
                    {
                        //change current to left child
                        current = current.left;
                        // System.Console.WriteLine("left");
                        left = true;
                    }
                    else if (current.value < value)
                    {
                        current = current.right;
                        //  System.Console.WriteLine("right");
                        left = !true;  //same as left = false
                    }
                    else
                    {
                        return;
                    }

                }
                //add value
                if (left)
                {
                    //  Console.WriteLine(value);
                    parent.left = new Node(value);
                }
                else
                {
                    //     Console.WriteLine(value);
                    parent.right = new Node(value);
                }
                //   Console.WriteLine("++========================++");
            }
        }

        /// <summary>
        /// Prints level-by-level throught tree
        /// </summary>
        public void LeveledPrint()
        {
            // Create a queue to store our nodes 
            Queue<Node> cue = new Queue<Node>();

            // Add the root to queue
            cue.Enqueue(root);

            // Counter to keep track of the levels
            int levelCounter = cue.Count();

            while (cue.Count() > 0)
            {
                if (levelCounter == 0)
                {
                    //go to the next level
                    Console.WriteLine();
                    //set our counter to the number of nodes in our queue
                    levelCounter = cue.Count();
                }

                //store it in a node variable
                Node current = cue.Dequeue();

                Console.Write(current.value + " "); //add a space to separate nodes

                //if there is a left child
                if (current.left != null)
                {
                    //add it to our queue
                    cue.Enqueue(current.left);
                }
                if (current.right != null) cue.Enqueue(current.right);

                levelCounter--; 
            }
        }

        /// <summary>
        /// Start to initilize with root
        /// </summary>
        /// <param name="name">Name of file</param>
        public void TreeHeight(string name)
        {
            // Call recursive CalDepth with root
            int height = CalDepth(root);
            // Print outcome
            Console.WriteLine("\n\nHeight of " + name + " is " + height.ToString() + ".");
        }

        /// <summary>
        /// Recursive method to find depth of tree and print recursively 
        /// </summary>
        /// <param name="node">Parse Node</param>
        /// <returns></returns>
        private int CalDepth(Node node)
        {
            // Found leaf
            if (node == null)
            {
                return 0;
            }
            else
            {
                // Move dieper within tree
                int leftDepth = CalDepth(node.left);
                int rightDepth = CalDepth(node.right);

                // Counting and returning int
                if (leftDepth > rightDepth)
                {
                    return (leftDepth + 1);
                }
                else
                {
                    return (rightDepth + 1);
                }
            }
        }

        /// <summary>
        /// Printing tree from highest number to lowest number
        /// </summary>
        /// <param name="name">Name of file</param>
        public void DecreaseOrderPrint(string name)
        {
            Console.WriteLine("\nPrinting " + name + " in decrease order: ");
            DecreaseOrder(root);
            Console.WriteLine("End of Printing");
        }

        /// <summary>
        /// Recursive method to print in decresing order
        /// </summary>
        /// <param name="node"></param>
        private void DecreaseOrder(Node node)
        {
            if (node == null)
            {
                return;
            }

            DecreaseOrder(node.right);

            Console.WriteLine(node.value);

            DecreaseOrder(node.left);
        }

        /// <summary>
        /// Print all prime numbers in increasing order
        /// </summary>
        public void PrimeInOrder()
        {
            Console.WriteLine("Printing Primes:");
            //start checking our tree for values
            InOrder(root); // Initiate recursive with root
            Console.WriteLine("End Printing .....");
        }

        /// <summary>
        /// Recursive method to get values of this BST
        /// </summary>
        /// <param name="node"></param>
        private void InOrder(Node node)
        {
            bool flag;
            // stop traversing
            if (node == null)
            {
                return;
            }

            //go left as possible
            InOrder(node.left);  //print the value
            
            if ((flag = IsPrime(node.value)) == true)
            {
                Console.WriteLine(node.value);
            }
            //go right as possible
            InOrder(node.right);
        }

        /// <summary>
        /// Check if number is prime and return bool
        /// </summary>
        /// <param name="num">Number to be checked</param>
        /// <returns></returns>
        private bool IsPrime(int num)
        {
            if ((num % 2) == 0)
            {
                return false;
            }
            for (int i = 2; i < num; i++)
            {
                if ((num % i) == 0)
                {
                    return false;
                }
            }
            return true;
        }
    }
}
