﻿using System;
using System.IO;

namespace BinarySearchTree_Assignment_Section_B_Jaco_Storm
{
    /*
     
        Jaco Storm 
        Assignment 1 
        Section B
        Binary Search Tree

        Instructions:

        1. Reads the integers in file1.txt, file2.txt and file3.txt and inserts them into binary search trees
           bst1, bst2 and bst3 respectively.

        2. Prints to the screen the size of each tree.

        3. Prints to the screen the numbers in each tree in decreasing order.

        4. Prints the height of each binary search tree.

        5. Prints the numbers in the binary search tree “level by level”. Done

        6. Print the number of prime numbers in the second binary search tree.

     */
    class Program
    {
        private static string bst1Path = "C:\\Users\\JacoS\\Desktop\\DataStructures\\TestData for Assignmemt_1\\file1.txt";
        private static string bst2Path = "C:\\Users\\JacoS\\Desktop\\DataStructures\\TestData for Assignmemt_1\\file2.txt";
        private static string bst3Path = "C:\\Users\\JacoS\\Desktop\\DataStructures\\TestData for Assignmemt_1\\file3.txt";
        private static string bst1Name = "File 1";
        private static string bst2Name = "File 2";
        private static string bst3Name = "File 3";

        static void Main(string[] args)
        {
            // Loading data into app and creating trees
            Load_data(bst1Name, bst1Path);
            Load_data(bst2Name, bst2Path);
            Load_data(bst3Name, bst3Path);

            // Pause console
            Console.ReadKey();
        }

        /// <summary>
        /// Loads data from text file.
        /// </summary>
        /// <param name="name">File name</param>
        /// <param name="filePath">Path of file to be loaded</param>
        private static void Load_data(string name,string filePath)
        {
            try
            {
                Tree aTree = new Tree();
                int[] wholeArray = null;
                int treeSizeCounter = 0;
                
                Console.WriteLine("\n\n*************************   " + name + "   *************************");
                //creategap();

                string[] fileContent = File.ReadAllLines(@"" + filePath);
                foreach (string line in fileContent)
                {
                    // Split values
                    string[] elements = line.Split(',');
                    // Convert array into int
                    wholeArray = Array.ConvertAll(elements, int.Parse);
                }

            
                foreach (int element in wholeArray)
                {
                    aTree.Insert(element);
                    treeSizeCounter++;
                }
                
                reporting(aTree, name, treeSizeCounter);
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error = " + ex.Message);
            }
            
        } //  End of method

        /// <summary>
        /// Create a report to print level-by-level, display tree height, print size of tree, print in decreasing order, print only prime numbers.
        /// </summary>
        /// <param name="aTree">Tree Node</param>
        /// <param name="name">File name</param>
        /// <param name="counter">Int counter</param>
        private static void reporting(Tree aTree, string name, int counter)
        {
            // Prints level-by-level throught tree
            aTree.LeveledPrint();
            //Recursive method to find depth of tree and print recursively 
            aTree.TreeHeight(name);
            // Prints size of tree with counter
            Console.WriteLine(name + " tree Size is: " + counter.ToString());
            // Printing tree from highest number to lowest number
            aTree.DecreaseOrderPrint(name);

            creategap();

            // Print all prime numbers in increasing order
            aTree.PrimeInOrder();
        }

        /// <summary>
        /// Creates single line gap during printing
        /// </summary>
        private static void creategap()
        {
            Console.WriteLine("\n");
        }
    }
}
